print(6 > 3 and 2 < 3)
print(3 > 6 or 2 < 3)
print('a' == 'a' and 'a' == 'b')
print(9 > 3 and 5 > 4)