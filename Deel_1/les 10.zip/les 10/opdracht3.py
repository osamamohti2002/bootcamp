naam = input('wat is je naam')
leeftijd = int(input('wat is je leeftijd'))

if leeftijd >= 18:
    print(f'beste {naam} , je bent 18 of ouder en mag dus alleen autorijden met rijbewijs.')
else:
    print(f'Beste {naam}, je bent nog geen 18. Alleen autorijden zit er dus niet in :-( ')

